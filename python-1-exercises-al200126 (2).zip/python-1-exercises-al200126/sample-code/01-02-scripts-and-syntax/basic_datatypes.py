my_string = "Python"
print(my_string)#Python
print(type(my_string))#<class 'str'>

# int(my_string)#ValueError: invalid literal for int() with base 10: 'Python'

my_number_as_string = "1"
print(type(my_number_as_string))
my_number_as_string = int(my_number_as_string)
print(type(my_number_as_string))#<class 'int'> - datatype changed

my_int = 1
print(type(my_int))#<class 'int'>

my_float = 1.0
print(type(my_float))#<class 'float'>

my_complex = 1 + 2j
print(type(my_complex))#<class 'complex'>

my_boolean = True
print(type(my_boolean))#<class 'bool'>

my_list_nums = [1,2,3]
print(type(my_list_nums))#<class 'list'>

my_list_names = ["George", "Ken", "Bernard"]
print(type(my_list_names))#<class 'list'>
