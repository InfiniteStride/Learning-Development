# 1

# double_it.py
# times_2.py
# 2_times.py#permissible but not best practice
# DoubleIt.py #for class names only
# times-2.py#permissible but not best practice
# twotimes.py#permissible but not best practice

# 2
#

# 3
# newline character only

# 4
# true

# 5
# print("Hello")