    # print("i am not indented in a block")#IndentationError: unexpected indent
print("i am not indented in a block")#works

# statements ending in : denote a code block immediately following
# this block must be indented one tab (4 spaces or editor prefs)
# when the indent returns to the LH margin
# the block is exited
if False:
    print("I am indented in a block")
    print("I am also indented in the same block")
    # even comments should be indented to the level they refer to
    # within the same block, ANY level of indent is technically OK
    # but should be consistent within the block
    # however 4 spaces / 1 tab is standard

print("I am now back on the LH margin")