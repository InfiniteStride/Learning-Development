# the input() function takes keyboard input from the user 
# (usually in this context the dev/tester)

# prompt user:
# print("Enter your name:")
# name = input()#waits for enter on CMD line
# we can collapse the first two lines into one
name = input("Enter your name:")#waits for enter on CMD line
print(name)
print(type(name))

# the input() function ALWAYS returns a string (class str)

gross_salary = input("Enter your gross salary")
# print("salary after income tax:", gross_salary * 80/100)
# 1st error
# TypeError: unsupported operand type(s) for /: 'str' and 'int'
print("salary after income tax:", int(gross_salary) * 80/100)#works
# in the above, two, separate, arguments are sent to the print function

# print("salary after income tax:" + int(gross_salary) * 80/100)#TypeError: can only concatenate str (not "float") to str
print("salary after income tax: " + str(int(gross_salary) * 80/100))#works

# there is a better way to do this since Python 3.5

# PLACEHOLDERS Python 3>
print("My name is {} and my net salary is {}".format(name, int(gross_salary) * 80/100))

# PLACEHOLDERS Python 3.5>
print(f"My name is {name} and my net salary is {int(gross_salary) * 80/100}")

# PLACEHOLDERS Python 3.7>
print(f'''
My name is {name} 
and my net salary is {int(gross_salary) * 80/100}''')


