from TrainingCourseException import TrainingCourseException
class TrainingCourse:
    def __init__(self, title, duration, priceperperson):
        self.set_title(title)
        self.duration = duration
        self.priceperperson = priceperperson
        self.delegates = [] 
    def set_title(self, title:str) -> None:
        if title != "":
            self.title = title
        else:
            raise Exception("title must not be empty")
            # self.title = None
            # print("title must not be empty")
    def add_delegates(self, name):
        self.delegates.append(name)
    def get_total_revenue(self):
        return len(self.delegates) * self.priceperperson

course1 = None
try:
    course1 = TrainingCourse("", 4, 1600)#LOC that causs the Exception
    course1.add_delegates("Ken")
    course1.add_delegates("Bob")

except Exception as e:
    print(e.with_traceback(None),"course not created")
finally:
    # if course1.title:
        # print(course1.title)#permits empty title field
    if course1:
        print(f"Course Delegates are: {course1.delegates}")
        print(f"The total revenue is: £{course1.get_total_revenue()}")

print("*" *50)
