class TrainingCourseException(Exception){
    
}