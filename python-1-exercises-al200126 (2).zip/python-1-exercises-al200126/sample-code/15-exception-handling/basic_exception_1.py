"""
   from a user POV, exception handling enables the code to recover
   and carry on from a catastrophic event
   from a dev POV, it enables us to create and raise Errors 
   (objects with information about the problem)
   according to business logic 
   exceptions should be seen as creating opportunities
   (for our system to intervene)
   not so much as presenting difficulties
"""
# this code can produce two errors:
# ZeroDivisionError: float division by zero
# ValueError: could not convert string to float: 

try:
    num1 = float(input("Enter a first number:"))
    num2 = float(input("Enter a second number:"))
    quotient = num1 / num2
except ValueError:
    print("a non-number entered")
except ZeroDivisionError:
    print("cannot divide by zero")
# we can chain an else block same s with loops
# the optional else block will only execute if an error is not generated
else:#only if no exception caught
    print(f"quotient of {num1} divided by {num2} is {quotient}")
finally:#always, whether exception caught or not
    print("thank you and goodbye")

print("Carrying on regardless")


