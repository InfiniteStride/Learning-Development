'''
a class is
a BLUEPRINT or TEMPLATE for
creating objects of a certain user-defined type
there exist many system classes such as str and list
when we create our own classes, however, we create our own types
you may choose classes over dictionaries to represent complex data
as every instance of the class will have 
the same fields (variables) and
the same methods (functions)
whereas if we used dictionaries, every usage has to be defined again
classes enforce standards applied by all objects of that class
they may also restrict direct access to state variables (data hiding/encapsulation)

also, classes may INHERIT from other classes
ensuring less code duplication
'''
class Client:
    pass
# at minimum, this is an instance of a class
client = Client()
# client - executes second = Client() - executes first
print(client)#<__main__.Client object at 0x102402900>
# but this version of an instance has no props

# to declare props on our objects we need a constructor in the class
class Client:
    def __init__(self):
        #the keyword self is a reference to the current object under construction
        # in the constructor we may set props on all objects
        # this way (no constructor args) all values start off the smae hardcoded
        self.name = "Client name"
        self.email = "Client email"
        self.dependents = []

client2 = Client()
print(client2.name)
print(client2.email)
print(client2.dependents)
client2.name = "Alan"
print(client2.name)

class Client:
    def __init__(self, name, email):
        #the keyword self is a reference to the current object under construction
        # in the constructor we may set props on all objects
        # this way (no constructor args) all values start off the smae hardcoded
        self.name = name
        self.email = email
        self.dependents = []

client3 = Client("Donald", "potus@gov.us")
print(client3.name)
print(client3.email)

class Client:
    # Java defines class fields here
    def __init__(self, name, email):
        self.name = name
        self.email = email
        self.dependents = []
    def add_dependent(self, name):
        if name not in self.dependents:
            self.dependents.append(name)
    def __str__(self):
        return f"{self.name}, {self.email}, {self.dependents}"

client4 = Client("JD Vance", "jd@hillbillyelegy.movie")
client4.add_dependent("Granmaw")
client4.add_dependent("Donald")
print(client4.name)
print(client4.email)
print(client4.dependents)
print(client4)#<__main__.Client object at 0x104ebecf0>
# what is actually happening in a call to the builtin print() functions is this:
# print(client4.__str__())

