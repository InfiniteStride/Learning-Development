class Calculator:
    def __init__(self):
        self.total = 0
    def add(self, num):
        self.total += num
    def sub(self, num):
        self.total -= num
    def div(self, num):
        if num != 0:
            self.total /= num
    def mul(self, num):
        self.total *= num
    def equals(self):
        final_total = self.total
        self.total = 0
        return final_total
 
calc1 = Calculator()
print(calc1.total)
calc1.add(5)
calc1.add(5)
calc1.add(4)
calc1.add(6)
print(calc1.total)
print(calc1.equals())
print(calc1.total)
print(calc1.total)
calc1.add(5)
calc1.sub(5)
calc1.add(4)
calc1.mul(6)
print(calc1.total)
print(calc1.equals())
print(calc1.total)
 
 

# class Calculator:
#     def __init__(self):
#         self.total = 0

#     def add(self, num):
#         pass
#     def sub(self, num):
#         pass
#     def div(self, num):
#         pass
#     def mul(self, num):
#         pass
#     def equals(self):
#         # temporarily COPY the total into a new var
#         # re-assign total to zero
#         # return the new variable
#         # return self.total
#         pass
#     # can't reset the total after a return statement