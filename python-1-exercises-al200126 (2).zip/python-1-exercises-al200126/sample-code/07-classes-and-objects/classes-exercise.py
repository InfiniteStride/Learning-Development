# Objects and Classes
# In this exercise you will create a class to model a Training Course object. 

# Use TrainingCourse naming style NOT training_course!

# The class will contain both data and method attributes. 
# The data attributes will consist of a 
# course title,
# a duration ( in days ), 
# a course price (per person, per day) and 
# a list of delegate names. 

# The Training Course
# object will also require methods: 
# a method to add a name to the delegate list and 
# a method to display the total revenue generated for the Training Course object.
# hint: the number of delegates will be returned by the built-in len() function

# 1. Create a script called classes_exercise.py.
# 2. Create a class called TrainingCourse
# 3. Add a dunder __init__ method to ensure that a TrainingCourse object is created
# with the following data attributes: title, duration, pricePerPerson and an empty list
# called delegates.
# 4. Add a method called add_delegates that will accept a delegate name as a parameter
# and then append it to the delegates list i.e. self.delegates.append(name).
# 5. Add method called get_total_revenue which will return the total revenue generated for
# the Training Course object i.e. number of delegates * pricePerPerson.

# TEST YOUR Classes
# 6. Create a TrainingCourse object with the data attributes set to the following values:
# title: Python Programming 1
# duration: 4
# price per person: 1600
# delegates: [ ]
# 7. Use the addDelegate method to assign some names to the Training Course
# object’s delegates list.
# 8. Display to the console the total revenue generated for the TrainingCourse object.

class TrainingCourse:
    def __init__(self, title, duration, priceperperson):
        self.title = title
        self.duration = duration
        self.priceperperson = priceperperson
        self.delegates = []
    def add_delegates(self, name):
        self.delegates.append(name)
    def get_total_revenue(self):
        return len(self.delegates) * self.priceperperson
 
course1 = TrainingCourse("Python Programming 1", 4, 1600)
course1.add_delegates("Ken")
course1.add_delegates("Bob")
print(course1.title)
print(f"Course Delegates are: {course1.delegates}")
print(f"The total revenue is: £{course1.get_total_revenue()}")

print("*" *50)

class TrainingCourse:

    def __init__(self, title, duration, pricePerPerson):

        self.title = title

        self.duration = duration

        self.pricePerPerson = pricePerPerson

        self.delegates = []

    def add_delegates(self, name):

        if name not in self.delegates and len(self.delegates) <=10:

            self.delegates.append(name)

            print(f"Delegate {name} successfully added.\nThe current number of delegates is {len(self.delegates)}")

        else:

            print(f"Delegate {name} already registered for course {self.title} - will not be added.")

    def remove_delegate(self, name):

        self.delegates.remove(name)

        print(f"Delegate {name} successfully removed.\nThe current number of delegates is {len(self.delegates)}")

    def get_total_revenue(self):

        total_revenue = float(self.pricePerPerson) * len(self.delegates)

        return total_revenue
 
 
trainingCourse1 = TrainingCourse("Python Programming 1", 4, 1600)

trainingCourse1.add_delegates("George")

trainingCourse1.add_delegates("Ken")

trainingCourse1.add_delegates("Bernard")

trainingCourse1.remove_delegate("Bernard")

# trainingCourse1.add_delegates("Bernard")

print(trainingCourse1.delegates)

print(trainingCourse1.get_total_revenue())
 