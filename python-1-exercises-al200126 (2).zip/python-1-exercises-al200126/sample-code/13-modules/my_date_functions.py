def a_week_from_today():
    import datetime as dt
    today = dt.date.today()
    delta = dt.timedelta(days = 7)
    return today + delta

# from Ken
from datetime import datetime, timedelta
 
def one_week_from_now():
    new_date = datetime.now() + timedelta(days=7)
    new_date = new_date.strftime('%d-%m-%y')
    return new_date