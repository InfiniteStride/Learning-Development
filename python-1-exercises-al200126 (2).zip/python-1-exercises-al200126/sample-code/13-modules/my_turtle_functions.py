def draw_square(turtle, size):
    for _ in range(4):
        turtle.forward(size)
        turtle.right(90)

def draw_red_square(turtle, size):
    turtle.color('red')#ORDER
    turtle.fillcolor("black")#ORDER
    turtle.width(5)
    turtle.begin_fill()
    for _ in range(4):
        turtle.forward(size)
        turtle.right(90)
    turtle.end_fill()
