'''
Ken 1. datetime
Bernard 2. turtle
George 5. sys 
'''

import my_date_functions as mdf
print(mdf.a_week_from_today())#2026-01-30
assert str(mdf.a_week_from_today()) == "2026-01-30"#pass - no error
# assert str(mdf.a_week_from_today()) == "2026-01-31"#fail - raises AssertionErro

# ken function
print("Ken:")
print(mdf.one_week_from_now())

import turtle
import my_turtle_functions as mtf
# IMPORTANT:
my_turtle = turtle.Turtle()
# some code....
mtf.draw_red_square(my_turtle, 100)
# my_turtle.screen.mainloop() #keeps graphics window on 
# until CTRL+C in terminal OR CTRL+W on window -

import sys
for path in sys.path:
    print(path)

'''
/Users/alanlavender/Documents/ALL-DELIVERIES/ALL-PYP1/PYP1-al200126/python-1-exercises/sample-code/13-modules
/Library/Frameworks/Python.framework/Versions/3.13/lib/python313.zip
/Library/Frameworks/Python.framework/Versions/3.13/lib/python3.13
/Library/Frameworks/Python.framework/Versions/3.13/lib/python3.13/lib-dynload
/Users/alanlavender/Library/Python/3.13/lib/python/site-packages
/Library/Frameworks/Python.framework/Versions/3.13/lib/python3.13/site-packages
'''
from q5_module import q5_fn
print(q5_fn())