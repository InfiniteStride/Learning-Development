'''
strings are immutable, ordered containers of characters
they may contain duplicates
string methods return a NEW string
the original is unaffected but the same reference may be updated
to point to the new string instead
'''
s1 = "Hello" #Python checks running memory:
# is there already a "Hello" string object there?
# NO: encode one
s2 = "Hello" #Python checks running memory:
# is there already a "Hello" string object there?
# YES: create another ref to it
print(s1 == s2)#True - strings are immutable 
# and s1, s2 point to the same string in memory

list1 = ["Hello"]
list2 = ["Hello"]
print(list1 == list2)#True
# this is because the __str__ method for list class is overridden
# to return true if two lists contain the same items in the same order

class Thing:
    pass

thing1 = Thing()
thing2 = Thing()

print(thing1 == thing2)#False
# this is because the __str__ method for Thing class is NOT overridden

print(s1, id(s1))#Hello 4372673280
print(s2, id(s2))#Hello 4372673280
# string objects are immutable 
# so the second reference points to the same object as the first

# string methods do not mutate the immutable string in place
# rather, they perform a transformation on the string
# and return a new string
print(s1.upper())
print(s1)
# we can update the reference to point to the new string
s1 = s1.upper()
print(s1)
# s2 STILL references the original string
print(s2)
# as long as there is at least ONE ref to it
# a string is held in volatile, working memory
#  if we remove all refs
s2 = None#we are reassigning a different value to the s2 variable
# now, the string "Hello" is available in the running program
# for garbage collection - removal from memory

# by contrast mutable lists
print(list1, id(list1))#['Hello'] 4301518912
print(list2, id(list2))#['Hello'] 4301359296//different ids
print(list1, id(list1[0]))#4374344448
print(list2, id(list2[0]))#4374344448#same as s1, s2
# when we dereferenced s2, there were still two live refs to it in list1, list2

# raw strings
# sometimes escape characters need to be printed literally
# eg in a file path `C:\Users` backslash U is aUnicode escape
# print(file_path := "C:\Users")#SyntaxError: (unicode error) 'unicodeescape' codec can't decode bytes in position 2-3: truncated \UXXXXXXXX escape
# instead:
print(file_path := "C:\\Users")#works but poor readability
print(file_path := r"C:\Users")#works as a raw string

print(registered_symbol := '\u00ae')
print(waving_hand := '\U0001F44B')
print(dog_face := '\U0001F436')

print(f"The Unicode escape for a dog face emoji is: {"\U0001F436"}")
print(f"The Unicode escape for a dog face emoji is: {r"\U0001F436"}")