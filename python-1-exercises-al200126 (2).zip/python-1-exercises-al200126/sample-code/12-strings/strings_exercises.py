# 1.
print("What are those blue remembered hills,\nWhat spires, what farms are those?")
# 2.
print("He said \"feeling good is not doing good\"")
# print("He said "feeling good is not doing good"")
print('He said "feeling good is not doing good"')

# 3.
print('''
line1
line2''')
# 4.
print("Hello" + "world")
# 5.
print("Hello", "world")
print("Hello","world")
# 6.
city = "birmingham"
print(city.capitalize())
print(city)
# 7.
data = "   fred-THOMAS\n"
print(first_name_length := data.index("-"))#with whitespace
print(index_d := data.index("d"))#6
print(index_f := data.index("f"))#3
import re
word = re.compile('\w')
print(word.findall(data))
print(first_name_length := len(data[data.find("fred"):data.find("-")]))

data = data.strip().replace("-", " ").title()
print(data)