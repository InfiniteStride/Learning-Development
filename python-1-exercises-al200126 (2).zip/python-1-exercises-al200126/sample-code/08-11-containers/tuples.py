'''
a tuple is like a list whose members may not be re-assigned
as such, it is suitable for representing small amounts of
heterogeneous data (of different sorts)
often the result of a function
it is ordered
may permit duplicates
'''

# creation
my_tuple = ("Alan", 21, ["walking", "photography"], True)
my_empty_tuple = tuple()#not a lot of point in this
# as re-assignement of items not permitted

fib = (0,1,1,2,3,5,8,13,21,34)

# tuple methods
print(fib.count(1))
print(fib.index(21))

# we may perform tuple slicing AND tuple comprehensions
# tuple slicing returns a new tuple
print(high_numbers := fib[7:])

# iterating
for el in fib:
    print(el)

# enumerating: indices and values
for index, value in enumerate(fib):
    print(index, value)

# tuple arithmetic
print(fib + (55,89))
print(fib * 2)
print(fib)#original unchanged

# tuple comprehensions
print(over_20s := [element for element in fib if element > 20])#
# returns a list
print(elements_scaled := [element * 2 for element in fib])

a_single_element_tuple = ("Hello")
print(type(a_single_element_tuple))#<class 'str'>
a_single_element_tuple = ("Hello",)
print(type(a_single_element_tuple))#<class 'tuple'>
