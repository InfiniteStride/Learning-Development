'''
sets are UNordered, mutable containers that do not permit duplicates
as such, they are often used for converting lists with duplicates into unique values
more than this, they have many utility methods for comparing sets, useful for data science
'''

# creation
nums = {4,5,6,4,5,6}
empty_nums = set()#NOT an empty dict which is {}
empty_dict = {}
print(type(empty_dict))
print(type(empty_nums))#set
print(nums)#{4, 5, 6}

# common use: filter out duplicates
list_with_dupes = [1,2,3,1,2,3]
unique_nums = set(list_with_dupes)
print(unique_nums_as_list := list(unique_nums))

# comparing sets
nums1 = {44,55,66,44,55,66}
nums2 = {55,66,33,22,11}

print(common_values := nums1.intersection(nums2))#reflexive
print(common_values := nums2.intersection(nums1))#reflexive
print(different_values := nums1.difference(nums2))#non-reflexive
print(different_values := nums2.difference(nums1))#non-reflexive
print(all_different_values := nums1.symmetric_difference(nums2))#reflexive{33, 22, 11, 44}
print(all_different_values := nums2.symmetric_difference(nums1))#reflexive{33, 11, 44, 22}
print(nums1)#{66, 44, 55}
print(nums2)#{33, 66, 22, 55, 11}

names = {"Attila", "Vishnu", "John", "Marc", "alan", "tim", "Horatio"}
print(names)#{'John', 'Marc', 'alan', 'Horatio', 'Attila', 'Vishnu', 'tim'}
print(names)#{'tim', 'John', 'Vishnu', 'Attila', 'alan', 'Horatio', 'Marc'}
# {'alan', 'Horatio', 'tim', 'John', 'Attila', 'Marc', 'Vishnu'}
# {'Horatio', 'John', 'Vishnu', 'alan', 'Marc', 'tim', 'Attila'}
