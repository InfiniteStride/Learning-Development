name = input("Enter your name: ") or "friend"
print(f"Hello {name}")