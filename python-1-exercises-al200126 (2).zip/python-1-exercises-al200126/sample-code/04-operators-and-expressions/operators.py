# an expression involves operators (symbols that perform operations) 
# and operands (values that are transformed by the operator)
x = 1
x = x + 1
# the first line initialises x with a single value, 1
# the second line assigns x the result of an expression - itself plus 1
# the expression has an operator, +
# and two operands, x (again), and 1

# arithemetic operators
# +
# -
# *     - 2 squared is 2 * 2
# **    - 2 ** 3 is 2 cubed
# /
# %     - remainder, whole number division
# //    - quotient, whole number division
print(10/5)#2.0
print(10%5)#0
print(10//5)#2

print(10/3)#3.3333333333333335
# promotion going on: result for division is a float if ints are input
# standard for floating-point arithmetic
# IEEE 754 since the 80s
# we should not use float values where accuracy is of primary concern!
# we could format our output, but the inherent inacurracy is still there
print(f"formatted output: {(10/3):.2f}")

# promotion:
# the process of storing smaller datatypes in larger ones
print(10/3)#yields a float result as likely to be a fraction
print( 9 + 2)#int result as it will be whole number
print( 9 + 2.0)##float result as first operand promoted to match second

# non-numeric arithmetic
print("ho" * 3)
print("*" * 50)

# assignment operators
# = is single assignment
# += is compound assignment
# note these work for strings and numbers both
my_num = 1
my_num = my_num + 1
my_num += 1
print(my_num)#expected - 3

my_string = ""
my_string = my_string + "I "
my_string = my_string + "love "
my_string = my_string + "Python "
print(my_string)

# note this way of building strings is expensive in memory when long strings are involved
# other methods see https://www.tracedynamics.com/python-string-builder/

# walrus operator
# said to be like a walrus tusks lying on side :=
# assigns AND RETURNS AT ONCE
# BEFORE
x = 1
print(x)
# AFTER
print(y := 1)

# nested data with respect to tuples in particular
my_nested_dict = {
    "name":"Alan",
    "languages": ("Python", "Java", "JS")
}
# tuple within a dict
# tuple ELEMENTS may not be reassigned
# but the overall reference may be
# my_nested_dict["languages"][2] = "React"#TypeError: 'tuple' object does not support item assignment
my_nested_dict["languages"] = ("French", "English", "Irish")
print(my_nested_dict)

# things that are NOT very Python-esque:

# increment/decrement operators ++ / -- in other languages
# not in Python - use
# += or -= instead

# multiple assignment on one line:
x = 1; y = 2; z = 3

# much better:
x, y, z = 1, 2, 3

# assignment operator chaining - hard to read eg.
x = 1
y = 1
# may be written as
x = y = 1

# container operators
# dict multiple assignment
my_dict = {"name": "Alan", "age": 21}
name, age = my_dict["name"], my_dict["age"]
# square brackets notation for dictionary keys
# DOT notation for object props

# list
my_nums = [1,2,3]
first, second, third = my_nums[0], my_nums[1], my_nums[2]

# comparison operators
# <         less than
# <=        less than or equal to
# >         greater than
# >=        greater than or equal to
# 4 > 4    #order important
# !=        not equal to
# is        tests for IDENTITY: references the same object as



# shallow and deep copying
# identity with is operator
nums = [1,2,3]
other_nums = [1,2,3]
reference_copy_nums = nums

print(reference_copy_nums is nums)#True
print(other_nums is nums)#False
print(other_nums == nums)#True - dunder method for equals is given an implementation in list class

class A:
    pass
class B:
    pass
a = A()
b = B()
a2 = A()
print(a2 == a)#False
# if we were to implement/override the dunder method that says how the == operator works
# then this test would yield True
print(a is b)#False
# even with the equality method overridden, this test will NEVER yield True
c = a #referential equality only: the two references point to the same object
print(c == a)#True (always)
print(c is a)#True (always)

# we declared:
# nums = [1,2,3]
# other_nums = [1,2,3]
# reference_copy_nums = nums

reference_copy_nums.append(4)
print(reference_copy_nums)#[1, 2, 3, 4]
print(nums)#[1, 2, 3, 4]
# because the copy copies the reference only it is called a SHALLOW copy
# the original may be mutated through the new reference
import copy
nums_shallow_copy = copy.copy(nums)
nums_shallow_copy.append(5)
print(nums_shallow_copy)#[1, 2, 3, 4, 5]
print(nums)#[1, 2, 3, 4]

# does this work with nested data at levels of recursion?
nested_nums = [1,2,3,[4]]#reference WITHIN a reference
nested_nums_shallow_copy = copy.copy(nested_nums)
nested_nums_shallow_copy[3].append(5)
print(nested_nums_shallow_copy)#expected [1,2,3[4,5]]
print(nested_nums)#expected [1,2,3[4]] - GOT [1, 2, 3, [4, 5]]

nested_nums_deep_copy = copy.deepcopy(nested_nums)
nested_nums_deep_copy[3].append(6)
print(nested_nums_deep_copy)#[1, 2, 3, [4, 5, 6]]
print(nested_nums)#[1, 2, 3, [4, 5]]#works at ANY level of recursion, for ALL container types