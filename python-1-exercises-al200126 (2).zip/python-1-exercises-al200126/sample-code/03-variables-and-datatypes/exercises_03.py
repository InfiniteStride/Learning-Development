'''
Bernard 1-5
Ken 6-10
George
11-15
ALL 16,17'''

# 1.
'''
data
name
data
data
data
data
name
'''
# 2.
# 900
# 3.
# 4.
# 5.
# 6.
# 7. 8.
tries = 3
print(tries * 5)
 
conversions = 2
penalties = 1
print(tries * 5 + conversions * 2 + penalties * 3)#this result does not persist
# its value cannot be re-used
# for reuse we must assign
score = tries * 5 + conversions * 2 + penalties * 3
print(score)
# print(score = tries * 5 + conversions * 2 + penalties * 3)
# TypeError: print() got an unexpected keyword argument 'score'
print(score := tries * 5 + conversions * 2 + penalties * 3)
# walrus operator := assigns and returns at the same time

# 10.
'''
int
float
str
bool
'''
# 11.
# print(type(x))

# 12.
nums = [10,20,30]
nums[1]
# 13.
# names[0] = "Tom"
# 14.
name = "John Smith"
email = "jsmith@mail.com"
client = {name:email}
client["John Smith"]
'''
>>> name = "John Smith"
>>> email = "jsmith@mail.com"
>>> name
'John Smith'
>>> email
'jsmith@mail.com'
>>> client = {name:email}
>>> client
{'John Smith': 'jsmith@mail.com'}
>>> client["John Smith"]
'jsmith@mail.com'
>>> client = {"name": "John Smith", "email": "jsmith@mail.com"}
>>> #NOT
>>> client.email
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
    client.email
AttributeError: 'dict' object has no attribute 'email'
>>> #BUT INSTEAD
>>> client["email"]
'jsmith@mail.com'
>>> 
'''
# 15.
football_match = {
    "home_team": "Chelsea",
    "away_team": "Liverpool",
    "home_team_score": 0,
    "away_team_score": 0
}
# your code here
football_match["away_team_score"] = 1

print(football_match)

# 16.
# 124
# 17.
# 1231
