# the standard, builtin datatypes
# literals, or single values, OR expressions that evaluate to them
# IMMUTABLE, by default

# boolean or bool
# values: True of False
# immutable type

my_bool = True # apart from two edge cases, 
# Python variables must always be initialised 
# (assigned a value on declaration)
# this is because there is now keyword associated with declaration
my_bool = False #re-assigned
# NOT a mutation True becomes False

# int or whole number
# values: whole numbers, or an expression that evaluates to them
# immutable type
my_int = 1
my_int = 2

# float or decimal number
# values: fractional numbers comprising digits 0-9 and the dot operator
# immutable type
my_float = 1.0
my_float = 1.5

# str (strings)
# values: any characters of zero or more
# immutable type
# single, double, triple-quoted
# zero-indexed, ordered
# have a length prop, obtained using len()

my_str = "Hello"
my_str = "Goodbye"

# string methods do not mutate the original
print(my_str.upper())# GOODBYE
print(my_str)#Goodbye
my_other_str = my_str#Goodbye copied into a new ref
my_str = my_str.upper()#old ref is re-assigned new value
print(my_str)#GOODBYE
print(my_other_str)#still Goodbye -the copied ref is NOT updated
# we may re-assign a new value to the same reference
# that doesn't mean the value itself is mutated
# just swapped out for a different one
# we may re-assign the reference (LHS of = assignment operator)
# doing so give the APPEARANCE we have changed the data
# but we have not, just swapped in different data.

# CONTAINER TYPES (for multiple values)

# LIST list() or []
# multiple values
# may be of same type but strictly do not have to be
# MUTABLE by default
# commonly used for items of same type
# permits duplicates

my_list = ["bat", "ball", "gloves"]
my_list_copy = my_list#copy of ref only
print(my_list)
print(type(my_list))
print(my_list[0])#first element
# update (mutate) a member
my_list[1] = "cricket ball"
# add new member
my_list.append("whites")
print(my_list)#['bat', 'cricket ball', 'gloves', 'whites']
print(len(my_list))
print(my_list_copy)#['bat', 'cricket ball', 'gloves', 'whites']

import copy
my_list_shallow_copy = copy.copy(my_list)#a NEW, separate list is cretaed
my_list_shallow_copy.append("shin pads")
print(my_list_shallow_copy)#['bat', 'cricket ball', 'gloves', 'whites', 'shin pads']
print(my_list)#['bat', 'cricket ball', 'gloves', 'whites']

# tuple
# a datatype that cannot have its ELEMENTS re-assigned
# but the overall reference maybe
my_tuple = ("bat", "ball", "gloves")
# my_tuple[0] = "cricket bat" #TypeError: 'tuple' object does not support item assignment
my_tuple = ("goal", "football", "boots")
print(my_tuple)
print(type(my_tuple))
# uses: to pass data to / return data from anotehr function where data must not be changed
# we can group unrelated data together 
my_restaurant = (" at the end of the universe ", 42, True)
# commonly, functions may return tuples

# sets
# values: teh elements can be of any type
# UNordered
# may NOT contain duplicates
# set methods are powerful tools for comparing different sets
my_set = {111,222,222,3,4,555,555}
print(my_set)#{3, 4, 555, 222, 111}
print(type(my_set))#
my_set_names = {"Alan", "Bernard", "George", "Ken"}
print(my_set_names)#{'Alan', 'George', 'Bernard', 'Ken'} 1time
# {'George', 'Bernard', 'Alan', 'Ken'} 2time

# dictionaries
# UNordered
# values: key: value pairs, comma-sep
# keys: may be of any type but are commonly strings and must be unique
# values: may be of any type and may be duplicated
# MUTABLE
# note: a Python dict is NOT the same as an object, 
# even though they both print out with curly braces and key: value pairs !
# neither are dicts the same as sets, even though both are encoded with curly braces
# objects are made by classes
# the way we drill down into properties is different
# theoretically EVERYTHING is an object in Python

my_dict = {"name": "Fred", "age":21, "employed": True}
print(my_dict)
print(type(my_dict))

# None type
my_none = None
print(my_none)
print(type(my_none))
# use None where you would use null in other languages
# it is used to de-reference objecst we no longer reqy=uire
# it points to nothing/nowhere

# truthiness - conversion to bool type
# everything in Python is inherently 
# TRUTHY (converts to True) or 
# FALSEY (converts to False)

print(bool(1))
print(bool(-99))
print(bool(0))#False
print(bool("0"))#True (ANY non-empty string)
print(bool(""))#False 
print(bool(my_list))#True 
print(bool([]))#False
print(bool(my_tuple))#True 
print(bool(()))#False
print(bool(my_set))#True 
print(bool({}))#False
print(type({}))#<class 'dict'>!!
print(type(set()))#<class 'set'>
print(bool(set()))#False

