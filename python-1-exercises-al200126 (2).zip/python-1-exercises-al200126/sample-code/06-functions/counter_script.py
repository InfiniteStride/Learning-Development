# from counter_module import globalincremental, counter
# from counter_module import *
import counter_module as c

print(c.globalincremental())
print(c.globalincremental())
print(c.globalincremental())
print(c.counter)

# is counter global to this script?
# no, it belongs to the module which is a subset of code available in this script
c.counter = 10
print(c.globalincremental())
print(c.globalincremental())
print(c.globalincremental())

counter = c.counter#13
print(counter)
# if we redefine counter form the module here in the script
# the module function is IMPURE
# it will still be looking for a counter in the gloabl namespace of the module
# the one it finds will be the old counter
print(c.globalincremental())
print(c.globalincremental())
print(c.globalincremental())#16 now
print(counter)#still 13 - hasnt tracked with function

print(c.pure_incremental(counter))#expect 14
print(c.pure_incremental(counter))#expect 14
print(c.pure_incremental(counter))#expect 14

#  /10.
# 1 (the function does nothing)

# 11. 11

# 12.
def do_something(num):
    if num == 0:
        return 0
    return num + do_something(num - 1)

result = do_something(3)
print(result)#6