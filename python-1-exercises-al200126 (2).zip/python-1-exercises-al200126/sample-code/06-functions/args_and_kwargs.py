def greet7(name, languages):
    return f"My name is {name} and I train {languages}"

print(greet7("Alan", ("Python", "Java", "JavaScript")))
# this is an aggregate association between the function and the languages parametr
# the languages exist separately and are passed in to the function
# we may wish alternatively to use a composition association
# where the languages only exist as part of the function
# *args parameter helps us with this

def greet8(name, *languages):
    return f"My name is {name} and I train {languages}"

print(greet8("Alan", "Python", "Java", "JavaScript"))
# *args
# the * is mandatory, the args is not
# none, one, or many args are packed into a tuple
# the *args parameter must come after any others

# the **kwargs (KEYWORD args) parameter packs any number of NAMED args into a dictionary
def greet9(name, *languages, **address):
    return f"My name is {name} and I train {languages}. I live in {address}"

print(greet9("Alan", "Python", "Java", "JavaScript", county="Donegal", country="Ireland"))

# **kwargs
# any number of named keyword arguments packed into a dictionary
# the ** is mandatory, the kwargs is not
# none, one, or many keyword args are packed into a dictionary
# the **kwargs parameter must come after any others INCLUDING *ARGS IF PRESENT

def greet10(name, age=21, *languages, **address):
    return f"My name is {name}, I am {age} years old and I train {languages}. I live in {address}"

# print(greet10("Alan", age=59, "Python", "Java", "JavaScript", county="Donegal", country="Ireland"))
# SyntaxError: positional argument follows keyword argument
# print(greet10(age=59, "Alan", "Python", "Java", "JavaScript", county="Donegal", country="Ireland"))
# SyntaxError: positional argument follows keyword argument
print(greet10("Alan", 59, "Python", "Java", "JavaScript", county="Donegal", country="Ireland"))
# the above runs but is potentially confusing
# print(greet10("Alan", "Python", "Java", "JavaScript", county="Donegal", country="Ireland", age=59))
# TypeError: greet10() got multiple values for argument 'age'

# the above LOC that works would be permissible but not necessarily beneficial
# the spec should be:
# positional args
# then *args
# then **kwargs
