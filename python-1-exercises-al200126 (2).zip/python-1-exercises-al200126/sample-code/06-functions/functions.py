'''
functions, as in any other language, wrap one or more LOC in a function name
to be called zero, one, or many times at some time in the future
functions are commonly defined in a script ON THEIR OWN, with no runtime code
the script with the runtime code in it, that USES the functions,
is separate, and IMPORTS them from the first script
the first script is called a module

how short can a function be?
1 LOC
why? to make code more declarative
the function name may be more descriptive than its workings
how long can a function be?
Not too long.
As a rule of thumb I would be wary of functions over 50-100 LOC
It is very likely they will have dependencies on other code.
If that other code were to break, so would your function.
You may never know this while unit testing
if a function consistently produces the same result for the same given input
it is said to be pure, or idempotent 
pure functions are much easier to test in an automated test environment
we do not have to mock dependencies that may change independently of the function
'''
# functions have input, output, both, or neither
# a print statement is NOT considered output
# a return statement is
# this output may be persisted in a variable
# or passed as INPUT to ANOTHER function
# input is taken in via parameter brackets ()
# even if there is no input the brackets must be there 
# both at function definition time and at runtime
# inside the brackets data is referred to as 
# PARAMETERS at function definition time
# ARGUMENTS (args) at runtime

# WAY 1, no input, no output
def greet1():
    print("Hello")
    print("from greet1")
    print("How are you today?")
# calling the function
greet1()
# can we persist this print output?
print(greeting1 := greet1())#None
print(greet1())# absolutely nothing, not even None
print(type(greet1))#<class 'function'>
print(greet1)#<function greet1 at 0x10426f920>

# WAY 2, no input, output (a return statement)
def greet2():
    return "Hello \nfrom greet2 \nHow are you today?"
# rules of return:
# you may only return one thing (though that thing may be complex data)
# the return must be the last statement in any route or branch through your function
# no code in the same block may come below a return statement
# it will be unreachable

greet2()#no visible output
# we need to pass on the return value to a collector so we may see it
print(greet2())
print(greeting2 := greet2())

# WAY 3, input, and output (parameters and a return statement)
def greet3(name):
    return f"Hello {name}\nfrom greet3 \nHow are you today?"
# print(greeting3 := greet3())#TypeError: greet3() missing 1 required positional argument: 'name'
print(greeting3 := greet3("Alan"))#works 
print(greeting3_wrong_args := greet3([1,2,3]))#also works - why?
# because list class has an implementation of a dunder method 
# that gives a string representation of a list object

# WAY 4, input, no output
def greet4(name):
    print("Hello " + name)
    print("from greet4")
    print("How are you today?")
print(greeting4 := greet4("George"))
print(greeting4)#None

# positional vs named args
# consider a function yjay accepts two args (positional)
def greet5(name, dob):
    return f"Hello {name} \nfrom greet5\nyou are {2026 - dob} years old next birthday "

print(greet5("Ken", 1967))
# print(greet5(1967, "Ken"))#TypeError: unsupported operand type(s) for -: 'int' and 'str'
print(greet5(1967, 1967))#works but not in right way

def greet6(name="friend", dob=1990):
    return f"Hello {name} \nfrom greet6\nyou are {2026 - dob} years old next birthday "
print(greet6(name="Bernard", dob=1997))
print(greet6(dob=1997, name="Bernard"))
print(greet6())

# default, named args
# 1. supply a value if not supplied at runtime
# 2. order of args and even missing args is no problem
