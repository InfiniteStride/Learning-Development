# basically, there are 3 ways of importing functions from a module
# module: a script that only holds functions and/or classes, and NOT runtime code
# WAY 1: fully-qualified (with module name)
import functions_module

# usage:
print(functions_module.greet6())
# PROS: there is no doubt ever at any point in your importing script that you are using a module function
# CONS: conversely, repeating the module name can be tedious
# as a refinement to way 1 you may use an alias, generally shorter than the module name:

# imports have to be before code that uses them
import functions_module as fm
print(fm.greet6())
# import functions_module as fm#NameError: name 'fm' is not defined

# WAY 2: named imports
# IMO is the best way

from functions_module import greet1, greet2 as g2 #we can still use aliases

# usage:

greet1()
print(g2())

# PROS: you can see exactly what's used at the top of the script
# no need for repetitive module name in each function call
# CONS: you could assume that functions which are actually imports
# are native functions, defined in the current script

# WAY 3: the wildcard
# IMO the worst way!

from functions_module import *#everything in the module

# usage:
greet4("Ken")
# PROS: easy and quick for development
# if you MUST use this way, consider swapping it for one of the others
# when re-testing for production code
# CONS: the next dev cannot see which functions are in the module
# or which functions are used in the script
# when a function is called from the module
# it looks identical to a function call from the script

