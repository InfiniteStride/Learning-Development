def greet1():
    print("Hello")
    print("from greet1")
    print("How are you today?")

def greet2():
    return "Hello \nfrom greet2 \nHow are you today?"

def greet3(name):
    return f"Hello {name}\nfrom greet3 \nHow are you today?"

def greet4(name):
    print("Hello " + name)
    print("from greet4")
    print("How are you today?")

def greet5(name: str, dob: int) -> str:#type hinting
    return f"Hello {name} \nfrom greet5\nyou are {2026 - dob} years old next birthday "

def greet6(name="friend", dob=1990):
    '''
    description (first thing inside a function)
    
    :param name: str
    :param dob: int
    '''
    return f"Hello {name} \nfrom greet6\nyou are {2026 - dob} years old next birthday "

# what of runtime code in a module?
# when a python file is imported as a module
# ALL AND ANY runtime code will run in the importing script
# print("I am runtime code here in the module")
# and it will run FIRST, before any other function calls

# if you do not wish for this behaviour
# we may hide runtime code in the module
# if you wish this code to run
# it will ONLY run when you run the module

if __name__ == "__main__":
    pass
# meaning: IF the name of this module 
# is also the name of the script that is being executed
    # print("I am runtime code here in the module but I am hidden from any importing scripts")

