counter = 20
def globalincremental():
    global counter #value is 20, shadowing global counter
    # NOT a declaration without an assignment
    # global counter has ALREADY been declared and assign
    # but in a different namespace
    # counter = 20
    counter += 1#when this assignment is made
    # it assigns to the global counter
    return counter

def pure_incremental(counter):#scope is parameterised:
    # a COPY of a number is passed in
    counter += 1
    return counter

def closure_incremental(func_name):
    # global func_name #error:
    # we cannot bind to a global var in the importing script
    # the name matters, 
    # and we cannot see the name in advance from the module
    def inner_function():
        counter += 1
        return counter
    return inner_function

