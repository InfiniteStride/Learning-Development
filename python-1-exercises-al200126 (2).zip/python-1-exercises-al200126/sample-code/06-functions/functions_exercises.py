'''
Ken     1-9 and 10
Bernard 1-9 and 11
George  1-9 and 12
'''
#1.
# This function will print "Hello" to stdout"

def hello():
    # '''
    # This function will print "Hello" to stdout"
    # '''
    '''
    Docstring for hello
    '''
    print("Hello")
 
 #1
print("\nQuestion 1")
# mf.hello()

#2.
# This function takes argument "name" and uses that in the output message to stdout
def hello_name(name: str) -> None:
    '''
    Docstring for hello_name
    
    :param name: name
    :type name: str
    '''
    print(f"Hello {name}")

# 3.
def bye_pers(name : str) -> str: # type hinting - we are signalling what type we are expecting as an input and as an output
    return f"Goodbye {name}"
# 4.
def multiply(x : float, y : float):
    return x*y
 
print(multiply(3.7,0.2))
 
#  multiple numbers to multiply
def multiply(*x):
    total = 1.0
    for num in x:
        total *= num
    return total

print(multiply(2,2,2))#8.0

# 5.
def first_element_in_list(list: list):
    return list[0]
print(first_element_in_list([1]))

# 6.
def first_and_last_name(person):
    print(person["fname"], person["lname"])
me = {"fname":"Alan", "lname":"Lavender"}
print(first_and_last_name(me))
me2 = {"first_name":"Alan", "lname":"Lavender"}
# print(first_and_last_name(me2))#KeyError: 'fname'

# 7.
# This function takes argument "name" and uses that in the output message to stdout
def hello_name_guest(name="Guest"):
    '''This function takes argument "name" 
    and uses that in the output message to stdout'''
    print(f"Hello {name}")
hello_name_guest("Alan")
hello_name_guest()
 
# This function returns the result of a number and exponent given as arguments
def num_exp1(num1=4, exp1=2):
    '''This function returns the result of a number and exponent given as arguments'''
    return num1**exp1
print(num_exp1(num1=2, exp1=3))
print(num_exp1(exp1=3, num1=2))
# 7. George modifying the dict question
# v2
# def fullname_printer(my_dict = {"fname":"Guest","lname":""}):
#     if my_dict["lname"] == False:
#         print(my_dict["fname"])
#     else:
#         print(my_dict["fname"] + " " + my_dict["lname"])

# v1
def fullname_printer(my_dict = {"fname":"Guest","lname":""}):
    if my_dict["lname"] == True:#will not directly compare to boolean
    # if my_dict["lname"]:#will coerce to boolean
        print(my_dict["fname"] + " " + my_dict["lname"])
    else:
        print(my_dict["fname"])

good_dict = {"fname":"Alan", "lname":"Lavender"}#expext Akan lavender
bad_dict_1 = {"fname":"", "lname":"Lavender"}#expect _ Lavender
bad_dict_2 = {"fname":"", "lname":""}#expect Guest
fullname_printer(good_dict)#Alan Lavender
fullname_printer(bad_dict_1)# Lavender
fullname_printer(bad_dict_2)#

# 9.
# This function returns the global variable counter incremented by 1.
counter = 20
def globalincremental():
    global counter #value is 20, shadowing global counter
    # NOT a declaration without an assignment
    # global counter has ALREADY been declared and assign
    # but in a different namespace
    # counter = 20
    counter += 1#when this assignment is made
    # it assigns to the global counter
    return counter

print(globalincremental())
print(globalincremental())
print(globalincremental())
print(counter)#20 #23 with global keyword

