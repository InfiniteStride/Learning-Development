'''
scope defines the visibility and lifespan of a variable
WHERE and WHEN it is seen / available
local scope:
-   declared within a function
-   visible only within the function or its blocks
-   lives and dies with the function execution
global scope:
-   declared outside of any functions
-   visible to all functions in the script
-   functions can see the scope chain "up and out" 
-   but not down and in
-   global scope lives whilst the whole script is executing
-   pure functions: accept copies of data, 
-   ALWAYS return the same thing EVERY time, for given same input
-   impure functions: have global dependencies on OTHER functions/variables,
-   do not always return same result for same given input
-   because their dependencies may change
-   impure functions are VERY hard to test
lexical scope:
-   defined as local function scope, lexical scope includes a "memory" of its parent function scope
-   this is achieved when a function is returned from the parent function with the local variable
-   that local variable becomes EFFECTIVELY GLOBAL for the function returned
-   lexical scope means functions can have memory and state persists between function calls

'''
# pure vs impure
next_num = 1#global var

# impure function
def get_next_num():
    return next_num + 1
# this function refers directly to a global var called next_num

print(get_next_num())#2
print(get_next_num())#2

next_num = 99

print(get_next_num())#100
print(get_next_num())#100
print(next_num)#99

# pure function
def get_next_num_pure(num):
    return num + 1
    # num param refers to ANY num passed in
# this function refers INdirectly to a COPY of ANY num passed in

print(get_next_num_pure(next_num))#100
print(get_next_num_pure(next_num))#100
# here, the arg is value 99
print(next_num)#99

next_num = 499
print(get_next_num_pure(next_num))#500
print(get_next_num_pure(next_num))#500
# here, the arg is value 499: input has changed
# when we change the number passed in, we call the function in a new way
print(next_num)#499

# we may BIND a global var toa function so that the function may mutate the global
# we do use a keyword to do this

# without binding, a local var starts and remains local scope
# even if it shares its name with a global

def local_scoped():
    next_num = 1000#separate scope to global
    return next_num

print(local_scoped())#next_num LOCAL is 1000
print(next_num)#next_num GLOBAL is 499

def bind_to_global():
    global next_num#499: tracks global
    next_num += 1#assigns 500
    return next_num

print(bind_to_global())#500
print(next_num)#500
print(bind_to_global())#501
print(next_num)#501

# what if we were to bind to the local variable in a similar way we bound to the global
# and return ANOTHER, INNER function which has the local variable as the next level up in its scope chain?

# we can do the following because:
# functions themselves are higher order objects (HOC/HOF) in Python
# this means they can be passed to and returned from other functions
# if we have an inner function, its effectively global scope
# is the parent, or outer functions's scope
# this scope level, to an inner function, is called LEXICAL scope
# it means: the outer function scope
# EFFECTIVELY global,
# to an inner function returned

def get_next_lexical_num():
    next_num = 3001#we wish to bind to this from inner func
    # EFFECTIVELY GLOBAL to inner func
    def get_next_num():
        nonlocal next_num#was 3001 when outer function invoked
        next_num += 1
        return next_num
    return get_next_num

# inner function, when invocated as part of a function expression,
# is said to create a CLOSURE around the lexically-scoped variable
# it not only remembers the value of its lexically-scoped environment at closure creation time
# it also persists this value IN BETWEEN function calls

my_closure = get_next_lexical_num()#a function expression, outer func invoked
# a "memory" of next_num at this time is created
print(my_closure())#3002
print(my_closure())#3003
print(my_closure())#3004
my_closure = get_next_lexical_num()#reset
print(my_closure())#3002
print(my_closure())#3003
print(my_closure())#3004


    

