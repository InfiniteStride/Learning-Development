'''
Loops come in two sorts: the while loop and the for loop
# while loops are commonly used for console IO
# there may be no obvious end to the process
# for loops are commonly used to iterate over containers
# the length of the container is known in advance
The for loop in Python is syntactic sugar for a while loop, 
usually when the number of iterations is known in advance.
There are no for loops at runtime, only while loops that the code is compiled into.
While loops in source code are useful when the number of iterations is not known in advance.

In Python, an optional else clause may be added to the end of both types of loop, for and while.
It is executed if the loop completes and doesn't hit a break statement.
In other words, if the loop completes normally.
To make this clearly readable, add a comment "# no break" next to the else clause.
'''
names = ['Michael Jackson', 'David Bowie', 'Janet Jackson', 'James Brown',
         'Gordon Brown', 'David Hume', 'Michael Jackson']

print(names)
#names is a container with a length prop
print(len(names))#7

# for loop (easy syntax)
for name in names:
    print(name)
    # name is an arbitary variable - it just stands for each element
    # names is a real name of a container

# while loop with a counter, for a collection
counter = 0
while counter < len(names):
    print(names[counter])
    counter += 1
    #important: omitting this gives you an infinite loop
    # the condition never becomes False so the loop carries on
    # and on

# while loop without a counter, for a collection:
guest_list = []
while True:
    name = input("Enter a name for the guest list, or type \"exit\" to quit")
    if name == "exit":
        break
    guest_list.append(name)
print(guest_list)

# while loop with neither counter nor collection
while True:
    birth_year = input("Enter the year you were born, or zero to quit")
    birth_year = int(birth_year)

    if birth_year == 0:
        break

    if birth_year < 1946:
        print("Age exempt from horrible postmodern categorising")
    elif birth_year in range(1946, 1966):#range(startIdxInclusive, endIdxExclusive)
        print(f"born in {birth_year}: baby boomer")
    elif birth_year in range(1966, 1976):
        print(f"born in {birth_year}: Gen X")
    elif birth_year in range(1976, 1994):
        print(f"born in {birth_year}: Millenial")
    else:
        print(f"born in {birth_year}: Gen Z")

# using break, continue, optional else:
for name in names:
    if name == "Janet Jackson":
        break#steps right out of loop
        # continue#steps out that iteration, then coems back to finish the loop
    print(name)
else:
    print("all names processed")#no break