'''
Bernard, 1-3 and 10
Ken, 4-6 and 10
George, 7-9 and 10'''

# number = int(input("enter a number: "))#works, but better pattern to separate
number = input("enter a number: ")
number = int(number)
# if number %2 != 0:#more readable
if number %2:
    print("Yes - it's odd!")
else:
    print("No - that's even!")

year_born = int(input("enter the year you were born: "))
 
if year_born < 1946:
    print("Maturist")
elif year_born < 1961:
# elif 1946 < year_born < 1961:#works but hard to read
    print("Baby Boomer")
elif year_born < 1981:
    print("Gen X")
elif year_born < 1996:
    print("Millenial")
else:
    print("Gen Z")

number = int(input("Enter a number: "))
current = 0
 
while current <= number:
    print(current)
    current += 2
 
total = 0
 
while True:
    num = input("Please enter a whole number between 1 and 100: ")
    if num == "q":
        break
    else:
        if int(num) > 100:
            print(f"Your number {num} is higher than 100")
            continue
        else:
            num = int(num)
            total += num
            print(total)

max_num = input("Enter a number: ")
max_num = int(max_num)
for num in range(0, max_num, 2):
    print(num)

nums = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
for num in nums:
    print(num ** 3)

users = [
    {"fname": "Tom", "lname": "Harrison"},
    {"fname": "Jane", "lname": "King"},
    {"fname": "Susan", "lname": "Johnson"},
    {"fname": "Mike", "lname": "Taylor"},
    {"fname": "Yanis", "lname": "Paulus"}
]
for user in users:
    print(user["fname"][0], user["lname"][0], sep="")
    print(f"{user["fname"][0]}{user["lname"][0]}")
    print(user["fname"][0] + user["lname"][0])

# 8
# 0,1,2,4

# 9
