'''
conditional statements are very smilar in Python to other languages,
they execute a block of code depending on whether a condition evaluates True or False
if True:
    code block, defined by indent, immediately following is executed
#separate if statements
if False:
    skipped

an else block has NO condition and means, really ANYTHING else

you can test multiple conditions using if elif else

following execution of any ONE branch the interpreter steps out of the statement structure, like a break

so when using ranges of values, if..elif blocks should be arranged with care to avoid unreachable code

Since recently in Python 3.10 there is another decision control statement
Called Structural Pattern Matching or match case
This mimicks the behaviour of switch in Java and JS, which traditionally has had no equivalent in Python
The match statement tests a single variable or expression for equality

'''

# single branch IF
if True:
    print("true path executed")
else:
    print("Carrying on regardless")

# two or more branch IF...ELIF...Else

country = input("enter country UK or IE:")
vat_rate = 0.0
if country == "UK":
    vat_rate = 20.0
elif country == "IE":
    vat_rate = 23.0
else:
    print("enter country either UK or IE")

if vat_rate:
    print(f"your VAT is at {vat_rate}%")
# you can have as many if...elif... clauses as you want
# BUT only ONE will execute

# comments should be at the level of indent they refer to

# if - else on one line
# forces a hard decision - one thing or another
# equivalent in other languages is ternary operator

temperature = "cold"
temperature = "scorchio"

print(clothing := "jumper" if temperature == "cold" else "T-shirt")

user = "Alan"
loggedIn = False
html = f"<p>Welcome {user}</p>" if loggedIn else "<p>Welcome guest</p>"

# if-elif-else with ranges
heart_rate = 120
bp = {"diastolic":130, "systolic":100}

if heart_rate < 130 and bp["diastolic"] <= 100:
    print("healthy individual")
elif heart_rate < 150 and bp["diastolic"] <= 120:
    print("ring your GP for a checkup")
else:
    print("go to A&E immediately if you are able")
