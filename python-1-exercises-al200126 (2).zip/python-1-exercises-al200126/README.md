<img src="https://github.com/stayahead-training/shared/blob/master/stayahead.png" />

# Python 1 Exercises

- [Getting Started](content/getting-started.md)
- [Scripts and Syntax](content/scripts-and-syntax.md)
- [Variables and Data Types](content/variables-and-data-types.md)
- [Operators and Expressions](content/operators-and-expressions.md)
- [Conditions and Loops](content/conditions-and-loops.md)
- [Functions](content/functions.md)
- [Objects and Classes](content/objects-and-classes.md)
- [Containers](content/containers.md)
- [Strings](content/strings.md)
- [Modules and Packages](content/modules-and-packages.md)
- [Pattern Matching](content/pattern-matching.md)
- [Exception Handling](content/exception-handling.md)
- [Files and the Filesystem](content/files-and-the-filesystem.md)
- [Databases](content/databases.md)